import { Component, OnInit } from '@angular/core';

import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Payment } from '../payment';
import { PaymentService } from '../payment.service';
import { SellerService } from '../seller.service';



@Component({
  selector: 'app-payment-details',
  templateUrl: './payment-details.component.html',
  styleUrls: ['./payment-details.component.css']
})
export class PaymentDetailsComponent implements OnInit {

  regForm: FormGroup;

  payment:Payment=new Payment();
  constructor(private fb: FormBuilder, private route: Router,private payservice:PaymentService,private sellerservice: SellerService) { }



  ngOnInit() {
    this.regForm = this.fb.group({
      cardnumber: ['', [Validators.required ]],
      expdate:['',[ Validators.required] ],
      cvv: ['', [Validators.required ]],
      cardname:['',[ Validators.required] ]
    });
  }
  
  pay()
  {
    this.payment= new Payment();
  }

  onPayment(){
    const obj={
      username:localStorage.getItem('username'),
      password: localStorage.getItem('password'),
      address: localStorage.getItem('address'),
      cardnumber: this.payment.cardnumber,
      expdate:this.payment.expdate,
      cvv:this.payment.cvv,
      cardname:this.payment.cardname,
      imageUrl:localStorage.getItem('imageUrl'),
      price: localStorage.getItem('price')
    }
    this.payservice.createPay(obj)
    .subscribe((data ) => {
      (console.log(data),error=>console.error(error));
    });
    this.sellerservice.deletefood().subscribe((data) =>{ (console.log(data),error=>console.error(error))
      this.route.navigateByUrl('food');
    });
    

  }
}
