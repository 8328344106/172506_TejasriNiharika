import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';
import { Employee } from '../employee';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  private islogin:boolean=false;
  constructor(private fb: FormBuilder, private route: Router, private userService:LoginService,private authservice:AuthService) { }
  regForm: FormGroup;
  submitted: boolean = false;
  response: any;
  employee:Employee=new Employee();


  ngOnInit() {
    this.authservice.checkingstatus();
    
    this.regForm = this.fb.group({
      username: ['', [Validators.required ]],
      password:['',[ Validators.required] ],
    });
   
  }
  login(){
    this.submitted=false;

    this.employee=new Employee();
  }
   check=true;
  onLogin(user,pass){

    localStorage.setItem('type','admin');
    this.userService.validateAdmin(this.employee)
      .subscribe((data) =>{
            (console.log(data),error=>console.error(error));
            if(data==true){
              this.check=true;
              localStorage.setItem('islogins',"true");
              localStorage.setItem('type','admin');
              localStorage.setItem('username',user);
              localStorage.setItem('password',pass);
              this.loginstatus();
              this.route.navigateByUrl('home');
              
            }
            else{
               this.check=false;
              this.route.navigateByUrl('adminlogin');
             }
            this.employee=new Employee();
      })    
   }
   loginstatus(){
     this.authservice.valid().subscribe((data) => {
       (console.log(data),error=>console.error(error));
       this.islogin=data
       
     });

   }

}
