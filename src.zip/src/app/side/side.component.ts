import { Component, OnInit } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { MatIconRegistry } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-side',
  templateUrl: './side.component.html',
  styleUrls: ['./side.component.css']
})
export class SideComponent implements OnInit {

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );
     
    islogins=localStorage.getItem('islogins');
    ngOnInit(){
    }
    constructor(private breakpointObserver: BreakpointObserver,
      iconRegistry: MatIconRegistry, 
      sanitizer: DomSanitizer,
      private authservice:AuthService,
      private route:Router) {

      iconRegistry.addSvgIcon(
          'menu',
          sanitizer.bypassSecurityTrustResourceUrl('assets/menu.svg'));
    
    iconRegistry.addSvgIcon(
      'person',
      sanitizer.bypassSecurityTrustResourceUrl('assets/person.svg'));
      iconRegistry.addSvgIcon(
        'account',
        sanitizer.bypassSecurityTrustResourceUrl('assets/account.svg'));
        iconRegistry.addSvgIcon(
          'register',
          sanitizer.bypassSecurityTrustResourceUrl('assets/register.svg'));
          iconRegistry.addSvgIcon(
            'logout',
          sanitizer.bypassSecurityTrustResourceUrl('assets/logout.svg'));
    }
    readvalue(key){
      return localStorage.getItem('islogins');
    }
    logout(){
      localStorage.setItem('islogins',JSON.stringify(false));
      localStorage.setItem('username',' ');
      localStorage.removeItem('type');
      this.authservice.logout();
    }
    
    read(){
      return localStorage.getItem('type');
    
    }
    reads(sell){
      return localStorage.getItem('type');
    }
    
}
