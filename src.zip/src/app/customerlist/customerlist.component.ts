import { Component, OnInit } from '@angular/core';
import { DataSource } from '@angular/cdk/collections';
import { LoginService } from '../login.service';
import { Gets } from '../gets';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customerlist',
  templateUrl: './customerlist.component.html',
  styleUrls: ['./customerlist.component.css']
})
export class CustomerlistComponent implements OnInit {

  dataSource: any=[];
  displayedColumns: any=[];
  reload(){
  this.dataSource = new UserDataSource(this.userservic);
  this.displayedColumns=['username','email','mobilenumber','password'];
  }
  constructor(private userservic:LoginService,private route:Router) { }

  ngOnInit() {
    this.reload();
    
  }
  ondelete(id){
    console.log("delete button is clicked",id);
    this.userservic.deletecustomer(id)
    .subscribe((data)=>{
      console.log(data),error=>console.error(error)

      this.reload();
    });
    
    
  }

}

export class UserDataSource extends DataSource<any>{
  constructor(private userservic: LoginService){
    super();
  }
  connect(): Observable<Gets[]>{
    return this.userservic.getAllCus();
  }
  disconnect(){}
}