export class Seller{
    id:number;
    username: string;
    password: string;
    imageUrl:string;
    price:string;
    service:string;
    description: string;
}