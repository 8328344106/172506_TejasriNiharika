import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './employee';
import { Register } from './register';
import { Gets } from './gets';

@Injectable({
    providedIn: 'root'
})
export class LoginService{
  
    private baseUrl = 'http://localhost:8888/customerregistor/register';
    private adminUrl='http://localhost:8888/admin/register';
    private sellerUrl='http://localhost:8888/sellerregistor/register';
    constructor(private http: HttpClient){

    }
    
    getAllCus(): Observable<Gets[]>{
        return this.http.get<Gets[]>(`${this.baseUrl}`+`/all`);
    }
    getsell():Observable<Gets[]>{
        return this.http.get<Gets[]>(`${this.sellerUrl}`+`/all`);
    }
    getEmployee(id: String):Observable<Object>{
        return this.http.get(`${this.baseUrl}/${id}`);
    }
    createUser(register: Object): Observable<Object>{
        return this.http.post(`${this.baseUrl}`+`/add`,register);
    }
    
    validateEmployee(employee: Object): Observable<Object>{
         return this.http.post(`${this.baseUrl}`+`/validate`,employee);
     
    }
    validateAdmin(employee: Object): Observable<Object>{
        return this.http.post(`${this.adminUrl}`+`/validate`,employee);
    
   }
   validateseller(employee: Object): Observable<Object>{
    return this.http.post(`${this.sellerUrl}`+`/validate`,employee);

    }
   createadmin(register: Object): Observable<Object>{
    return this.http.post(`${this.adminUrl}`+`/add`,register);
    }
    createseller(register: Object): Observable<Object>{
        return this.http.post(`${this.sellerUrl}`+`/add`,register);
    }
    
    deleteseller(id): Observable<any>
    {
        console.log(id);
        return this.http.delete(`${this.sellerUrl}/${id}`)
    }
    deletecustomer(id): Observable<any>
    {
        console.log(id);
        return this.http.delete(`${this.baseUrl}/${id}`)
    }
    
    
    

}