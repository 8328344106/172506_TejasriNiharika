import { Component, OnInit } from '@angular/core';
import { Seller } from '../seller';
import { SellerService } from '../seller.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminfoodlist',
  templateUrl: './adminfoodlist.component.html',
  styleUrls: ['./adminfoodlist.component.css']
})
export class AdminfoodlistComponent implements OnInit {

  constructor(private fb: FormBuilder, private sellerservice:SellerService,private route:Router,private bs:SellerService) { }
 
  seller:Seller[];
  
  check=false;
  ngOnInit() 
  {

    this.reloadData();
 
  }
  reloadData() {
    this.bs.getAllSellers().subscribe(data=>
      {
        this.seller= data as Seller[];
      });
  }
  read(username){
    return localStorage.getItem('username');
  }

}
