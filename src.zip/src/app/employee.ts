export class Employee {
    username: string;
    password : string;
}