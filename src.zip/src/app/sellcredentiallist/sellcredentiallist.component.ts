import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { Gets } from '../gets';
import { Observable } from 'rxjs';
import { DataSource } from '@angular/cdk/collections'
import { Router } from '@angular/router';
import { ResourceLoader } from '@angular/compiler';
import { RegisterComponent } from '../register/register.component';

@Component({
  selector: 'app-sellcredentiallist',
  templateUrl: './sellcredentiallist.component.html',
  styleUrls: ['./sellcredentiallist.component.css']
})
export class SellcredentiallistComponent implements OnInit {
  dataSource: any=[];
  displayedColumns: any=[];
  reload(){
  this.dataSource = new UserDataSource(this.userservice);
  this.displayedColumns=['username','email','mobilenumber','password'];
  }
  constructor(private userservice:LoginService,private route:Router) { }

  ngOnInit() {
    this.reload();
    
  }
  ondelete(id){
   
    this.userservice.deleteseller(id)
    .subscribe((data)=>{
      console.log(data),error=>console.error(error)
      this.reload();
    });
    
    
  }
  onEdit(){
    localStorage.setItem('edit','edit');
    console.log('hii');
    this.route.navigateByUrl('sellcre');
  }
  read(edit){
    return localStorage.getItem('edit');
  }
  onSubmit(){
    localStorage.removeItem('edit');
    this.route.navigateByUrl('sellcre');
  }
}

export class UserDataSource extends DataSource<any>{
  constructor(private userservice: LoginService){
    super();
  }
  connect(): Observable<Gets[]>{
    return this.userservice.getsell();
  }
  disconnect(){}
}