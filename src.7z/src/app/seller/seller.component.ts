import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Seller } from '../seller';
import { SellerService } from '../seller.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-seller',
  templateUrl: './seller.component.html',
  styleUrls: ['./seller.component.css']
})
export class SellerComponent implements OnInit {

  constructor(private fb: FormBuilder, private sellerservice:SellerService,private route:Router,private bs:SellerService) { }
 
  seller:Seller[];
  regForm: FormGroup;
  check=false;
  ngOnInit() 
  {

    this.reloadData();
 
  }
  reloadData() {
    this.bs.getAllSellers().subscribe(data=>
      {
        this.seller= data as Seller[];
      });
  }
  read(username){
    return localStorage.getItem('username');
  }
  reads(type){
    return localStorage.getItem('type');
  }
  
  

}
