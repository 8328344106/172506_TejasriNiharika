import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SellcredentiallistComponent } from './sellcredentiallist.component';

describe('SellcredentiallistComponent', () => {
  let component: SellcredentiallistComponent;
  let fixture: ComponentFixture<SellcredentiallistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SellcredentiallistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SellcredentiallistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
