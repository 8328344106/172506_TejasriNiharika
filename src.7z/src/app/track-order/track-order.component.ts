import { Component, OnInit } from '@angular/core';
import { PaymentService } from '../payment.service';
import { Payment } from '../payment';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'app-track-order',
  templateUrl: './track-order.component.html',
  styleUrls: ['./track-order.component.css']
})
export class TrackOrderComponent implements OnInit {

  url: SafeResourceUrl;
  constructor(private payservice:PaymentService,public sanitizer: DomSanitizer) { }
  payment:Payment[];
  ngOnInit() {
    this.reloadData();
    
    this.url = this.sanitizer.bypassSecurityTrustResourceUrl(this.address());
  }
  reloadData() {
    this.payservice.getAll().subscribe(data=>
      {
        this.payment= data as Payment[];
      });
  }
  address(){
    return localStorage.getItem('address');
  }

}
