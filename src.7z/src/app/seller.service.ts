import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable({
    providedIn: 'root'
})
export class SellerService{
    private baseUrl = 'http://localhost:9898/seller';
    private foodUrl = 'http://localhost:4567/food';
    constructor(private http: HttpClient){

    }
    // getSeller(img,p):Observable<Object>{
        
    // const obj = {
    //     imageUrl:img,
    //     price:p
    //   };
  
    //     return this.http.post(`${this.baseUrl}`+`/img`,obj);
    // }
    getAllSellers(): Observable<any>{
        return this.http.get(`${this.baseUrl}`+`/all`);
    }
    addUser(seller: Object): Observable<Object>{
        return this.http.post(`${this.baseUrl}`+`/add`,seller);
    }
    getAllfood(): Observable<any>{
        return this.http.get(`${this.foodUrl}`+`/all`);
    }
    addfood(seller:Object): Observable<Object>
    {
        return this.http.post(`${this.foodUrl}`+`/add`,seller);
    }
    read(){
        return localStorage.getItem('id');
    }
    deletefood(): Observable<any>
    {
        
        return this.http.delete(`${this.foodUrl}/${this.read()}`)
    }

}