import { Component, OnInit, Input } from '@angular/core';
import { LoginService } from '../login.service';

import { Register } from '../register';
import { Observable } from 'rxjs';
import { Seller } from '../seller';
import { SellerService } from '../seller.service';

@Component({
  selector: 'app-food-list',
  templateUrl: './food-list.component.html',
  styleUrls: ['./food-list.component.css']
})
export class FoodListComponent implements OnInit {
  

  seller: Seller[];
  sell:Seller=new Seller();
  
  constructor(private bs:SellerService) { }

  ngOnInit() {
    this.reloadData();
  }
  reloadData() {
    this.bs.getAllfood().subscribe(data=>
      {
        this.seller= data as Seller[];
      });
  }
  read(username){
    return localStorage.getItem('username');
  }

  onorder(img,p,ser,des,i){
    console.log(i);
    localStorage.setItem('id',i);
    localStorage.setItem('imageUrl',img);
    localStorage.setItem('price',p);
    localStorage.setItem('service',ser);
    localStorage.setItem('description',des);

  }

}
