export class Register{
    username: string;
	email: string;
	mobilenumber: string;
    password: string;
    repeatpassword: string;
    imageUrl: string;
}